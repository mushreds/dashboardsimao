import React, { useState, useEffect } from 'react';
import GaugeChart from './GaugeChart';
import { Calendar } from 'lucide-react';

const getDefaultDateRange = () => {
  const today = new Date();
  const year = today.getFullYear();
  const month = today.getMonth();
  const formatDate = (date) => {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  };
  return {
    startDate: formatDate(new Date(year, month, 1)),
    endDate: formatDate(new Date(year, month + 1, 0))
  };
};

const Header = ({ metrics, config, dateRange, onDateChange }) => {
  const [localStartDate, setLocalStartDate] = useState(dateRange.startDate);
  const [localEndDate, setLocalEndDate] = useState(dateRange.endDate);

  useEffect(() => {
    setLocalStartDate(dateRange.startDate);
    setLocalEndDate(dateRange.endDate);
  }, [dateRange]);

  const { vgvTotal = 0, vendasConsultaCount = 0, vendasCirurgiaCount = 0 } = metrics || {};
  const { metaVgv = 1200000, metaConsulta = 50, metaCirurgia = 16 } = config || {};

  const quickFilters = [
    { label: 'Hoje', val: 0 }, { label: '2D', val: 1 }, { label: '7D', val: 7 },
    { label: '15D', val: 15 }, { label: 'Mês', val: 30 }, { label: '3M', val: 90 },
  ];

  return (
    <header className="flex flex-col lg:flex-row items-center justify-between gap-6 pb-6 border-b border-border-card mb-6">
      <div className="flex items-center select-none self-start lg:self-center">
        <div className="flex flex-col">
          <span className="text-xl font-black text-white tracking-wider">Dr. Simão Sereno</span>
          <span className="text-[10px] text-gold-primary font-bold tracking-widest uppercase">Dashboard</span>
        </div>
      </div>

      <div className="flex items-center gap-4 flex-wrap justify-center">
        <GaugeChart label="Meta VGV" value={vgvTotal} max={metaVgv} prefix="R$ " formatType="money" />
        <GaugeChart label="Meta Consulta" value={vendasConsultaCount} max={metaConsulta} formatType="number" />
        <GaugeChart label="Meta Cirurgia" value={vendasCirurgiaCount} max={metaCirurgia} formatType="number" />
      </div>

      <div className="flex flex-col items-end gap-2.5 self-end lg:self-center">
        <div className="flex items-center gap-1 bg-bg-secondary border border-border-card p-1 rounded-xl shadow-inner select-none">
          {quickFilters.map((item) => {
            const today = new Date();
            let start = new Date(today);
            if (item.val > 0) start.setDate(today.getDate() - (item.val === 1 ? 1 : item.val - 1));
            const fmt = (d) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
            const startStr = fmt(start), endStr = fmt(today);
            const isActive = dateRange.startDate === startStr && dateRange.endDate === endStr;
            return (
              <button key={item.label} onClick={() => isActive ? onDateChange(getDefaultDateRange()) : onDateChange({ startDate: startStr, endDate: endStr })}
                className={`px-2.5 py-1 rounded-lg text-[9px] font-black uppercase tracking-wider transition-all cursor-pointer ${
                  isActive ? 'bg-[#2A2115]/50 border border-gold-primary text-[#FFF3E3] shadow-md gold-glow' : 'bg-transparent border border-transparent text-text-secondary hover:text-white'
                }`}>
                {item.label}
              </button>
            );
          })}
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 bg-bg-secondary border border-border-card rounded-xl px-3 py-1.5 text-xs font-semibold text-text-secondary shadow-md">
            <Calendar className="w-4 h-4 text-gold-primary" />
            <input type="date" value={localStartDate} onChange={(e) => setLocalStartDate(e.target.value)}
              className="bg-transparent text-white border-none outline-none cursor-pointer [color-scheme:dark]" />
            <span className="text-text-muted">até</span>
            <input type="date" value={localEndDate} onChange={(e) => setLocalEndDate(e.target.value)}
              className="bg-transparent text-white border-none outline-none cursor-pointer [color-scheme:dark]" />
          </div>
          {(localStartDate !== dateRange.startDate || localEndDate !== dateRange.endDate) && (
            <button onClick={() => onDateChange({ startDate: localStartDate, endDate: localEndDate })}
              className="px-3 py-2 bg-gold-primary hover:bg-gold-hover text-bg-primary font-bold rounded-xl text-[10px] uppercase tracking-wider shadow-md transition-all cursor-pointer gold-glow animate-pulse">
              Aplicar
            </button>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
